# FREEBSD
make -DGCC
make clean-all
make -DGCC -DC89
make clean-all
make -DGCC -DC90
make clean-all
make -DGCC -DC99
make clean-all
make -DGCC -DC11
make clean-all
make -DCLANG
make clean-all
make -DCLANG -DC89
make clean-all
make -DCLANG -DC90
make clean-all
make -DCLANG -DC99
make clean-all
make -DCLANG -DC11
make clean-all

# LINUX

make cc=GCC
make clean-all
make cc=GCC dialeto=C89
make clean-all
make cc=GCC dialeto=C90
make clean-all
make cc=GCC dialeto=C99
make clean-all
make cc=GCC dialeto=C11
make clean-all
make cc=CLANG
make clean-all
make cc=CLANG dialeto=C89
make clean-all
make cc=CLANG dialeto=C90
make clean-all
make cc=CLANG dialeto=C99
make clean-all
make cc=CLANG dialeto=C11
make clean-all

